package steps;

import io.cucumber.java8.En;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

public class API_Steps implements En {

    private Response response;
    private Map<String, String> formParams = new HashMap<>();

    public API_Steps() {

        Given("^existing Server application$", () -> {
            RestAssured.baseURI = "http://localhost:3000"; // or your actual base URI
        });

        When("^user sends GET request to \\/users$", () -> {
            response = get("/users");
        });

        Then("^response should contain users anna and bob$", () -> {
            String expectedJson = "[{\"name\":\"anna\",\"email\":\"anna@codility.com\"}," +
                                  "{\"name\":\"bob\",\"email\":\"bob@codility.com\"}]";
            assertEquals(200, response.statusCode());
            assertEquals(expectedJson, response.asString());
        });

        When("^user sends GET request to \\/new$", () -> {
            response = get("/new");
        });

        Then("^response should say welcome message$", () -> {
            assertEquals(200, response.statusCode());
            assertEquals("Welcome to the new page!", response.asString());
        });

        When("^user sends GET request to root path$", () -> {
            response = get("/");
        });

        Then("^response should be a redirect to \\/new$", () -> {
            assertEquals(301, response.statusCode());
            String body = response.asString();
            assertTrue(body.contains("Moved Permanently") && body.contains("/new"));
        });

        When("^user sends GET request to a non-existing endpoint$", () -> {
            response = get("/nonexisting");
        });

        Then("^response should return 404 error$", () -> {
            assertEquals(404, response.statusCode());
        });

        Given("^user provides name (.*) and email (.*) for POST$", (String name, String email) -> {
            formParams.clear();
            formParams.put("name", name);
            formParams.put("email", email);
        });

        When("^user sends POST request to \\/users$", () -> {
            response = given()
                        .contentType("application/x-www-form-urlencoded")
                        .formParams(formParams)
                       .post("/users");
        });

        Then("^response should confirm user added with name (.*) and email (.*)$", (String name, String email) -> {
            String expected = name + " with an email " + email + " added";
            assertEquals(200, response.statusCode());
            assertEquals(expected, response.asString());
        });

        Then("^response should say user already exists$", () -> {
            assertEquals(400, response.statusCode());
            assertEquals("User with this email already exists", response.asString());
        });

    }
}
