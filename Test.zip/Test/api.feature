Feature: API testing scenarios

  Scenario: GET request to /users
    Given existing Server application
    When user sends GET request to /users
    Then response should contain users anna and bob

  Scenario: GET request to /new
    Given existing Server application
    When user sends GET request to /new
    Then response should say welcome message

  Scenario: GET request to root path
    Given existing Server application
    When user sends GET request to root path
    Then response should be a redirect to /new

  Scenario: GET request to a non-existing endpoint
    Given existing Server application
    When user sends GET request to a non-existing endpoint
    Then response should return 404 error

  Scenario Outline: POST request to /users with name and email
    Given existing Server application
    And user provides name <name> and email <email> for POST
    When user sends POST request to /users
    Then response should confirm user added with name <name> and email <email>

    Examples:
      | name  | email               |
      | clark | clark@codility.com |
      | dan   | dan@codility.com   |
      | admin | admin@codility.com |

  Scenario: POST request with duplicate email
    Given existing Server application
    And user provides name incorrect and email anna@codility.com for POST
    When user sends POST request to /users
    Then response should say user already exists
